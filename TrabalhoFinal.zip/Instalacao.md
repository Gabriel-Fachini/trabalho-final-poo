# Manual de instalação
1. Mude o terminal para a pasta src<br>
> `$ cd src`

2. Execute a instalção das dependências rodando o comando<br>
> `$ pip install -r requirements.txt`

3. Após feito tudo isso, basta executar com python o arquivo principal<br>
> `$ python3 main.py`